function resize(){

}

$(document).ready(function(){
	resize();
});